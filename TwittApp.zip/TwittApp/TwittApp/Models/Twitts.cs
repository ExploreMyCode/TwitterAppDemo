﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwittApp.Models
{
    public class Twitts
    {
        public List<TwitterMessage> AllMessages { get; set; }
        public List<TwittHeader> TwittHeaderDetails { get; set; }
    }
}