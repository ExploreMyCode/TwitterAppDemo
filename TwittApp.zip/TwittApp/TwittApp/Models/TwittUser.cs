﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwittApp.Models
{
    public class TwittUser
    {
        public string UserName { get; set; }
        public int UserTwittsCount { get; set; }
    }
}