﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TwittApp.Models
{
    public class TwittHeader
    {
        public string AccountName { get; set; }
        public int TwittCountsByAccount { get; set; }
        public List<TwittUser> TwittUsers {get;set;}
    }
}