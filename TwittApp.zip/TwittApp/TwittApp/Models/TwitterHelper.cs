﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Web;
using System.Xml.Linq;

namespace TwittApp.Models
{
    public class TwitterHelper : ITwitterHelper 
    {
        private const string TW_ACCOUNT1 = "pay_by_phone";
        private const string TW_ACCOUNT2 = "PayByPhone";
        private const string TW_ACCOUNT3 = "PayByPhone_UK";

        public TwitterHelper()
        {

        }

        /// <summary>
        /// Get the list of users and number of twitts per user based on account type
        /// </summary>
        /// <param name="messages"></param>
        /// <param name="accountName"></param>
        /// <returns></returns>
        public List<TwittUser> GetUserDetailsPerAccount(List<TwitterMessage> messages, string accountName)
        {
            List<TwittUser> users = (from m in messages
                                     where m.AccountName == accountName
                                     group m by m.UserName into g
                                     select new TwittUser { UserName = g.Key, UserTwittsCount = g.Count() }).ToList<TwittUser>();
            return users;
        }

        /// <summary>
        /// Get the list all merged twitts, sorted based in datetime. It also does aggregation for account and users.
        /// </summary>
        /// <returns></returns>
        public Twitts GetTwitts()
        {
            Twitts twitts = new Twitts();
            List<TwitterMessage> messages = GetAllTwitterMessages().OrderByDescending(x => x.CreatedDate).ToList();
            twitts.AllMessages = messages;
            twitts.TwittHeaderDetails = new List<TwittHeader>();
            
            List<TwittUser> users = null;
            TwittHeader header = null;
            //For TW_ACCOUNT1              
            users = GetUserDetailsPerAccount(messages, TW_ACCOUNT1);
            header = new TwittHeader();
            header.AccountName = TW_ACCOUNT1;
            header.TwittCountsByAccount = messages.Where(m=>m.AccountName.Equals(TW_ACCOUNT1, StringComparison.InvariantCultureIgnoreCase)).Count();
            header.TwittUsers = new List<TwittUser>();
            if (users.Count() > 0 )
            header.TwittUsers.AddRange(users);
            twitts.TwittHeaderDetails.Add(header);
            //For TW_ACCOUNT2              
            users = GetUserDetailsPerAccount(messages, TW_ACCOUNT2);
            header = new TwittHeader();
            header.AccountName = TW_ACCOUNT2;
            header.TwittCountsByAccount = messages.Where(m => m.AccountName.Equals(TW_ACCOUNT2, StringComparison.InvariantCultureIgnoreCase)).Count();
            if (users.Count() > 0)
            {
                header.TwittUsers = new List<TwittUser>();
                header.TwittUsers.AddRange(users);
            }
            twitts.TwittHeaderDetails.Add(header);

            //For TW_ACCOUNT3
            users = GetUserDetailsPerAccount(messages, TW_ACCOUNT3);
            header = new TwittHeader();
            header.AccountName = TW_ACCOUNT3;
            header.TwittCountsByAccount = messages.Where(m => m.AccountName.Equals(TW_ACCOUNT3, StringComparison.InvariantCultureIgnoreCase)).Count();
            if (users.Count() > 0)
            {
                header.TwittUsers = new List<TwittUser>();
                header.TwittUsers.AddRange(users);
            }
            twitts.TwittHeaderDetails.Add(header);
            
            return twitts;
        }


        /// <summary>
        /// Get the twitter data by account name 
        /// </summary>
        /// <param name="accountName"></param>
        /// <returns></returns>
        public IEnumerable<TwitterMessage> GetTwitterMessageByAccountType(string accountName)
        {
            string url = "https://api.twitter.com/1/statuses/user_timeline.xml?include_entities=true&include_rts=true&screen_name=" + accountName + "&count=200";
            WebClient client = new WebClient();
            string twittData = client.DownloadString(url);
            XDocument doc = XDocument.Parse(twittData);
            string formatString = "ddd MMM dd HH:mm:ss zzzz yyyy";
            //read the data form xdocument
            var result = from status in doc.Descendants("status")
                         where (status.Element("retweeted_status") != null ? DateTime.ParseExact(status.Element("retweeted_status").Element("created_at").Value, formatString, null) : (status.Element("created_at") != null ? DateTime.ParseExact(status.Element("created_at").Value, formatString, null) : DateTime.Now)) > DateTime.Now.AddDays(-14) 
                         select new TwitterMessage
                         {
                             CreatedDate = (status.Element("retweeted_status")!= null ? DateTime.ParseExact(status.Element("retweeted_status").Element("created_at").Value, formatString, null) :  (status.Element("created_at") != null ? DateTime.ParseExact(status.Element("created_at").Value, formatString, null) : DateTime.Now)),
                             Text = (status.Element("retweeted_status") != null ? status.Element("retweeted_status").Element("text").Value : (status.Element("text") != null ? status.Element("text").Value : null)),
                             TextId = (status.Element("retweeted_status") != null ? status.Element("retweeted_status").Element("id").Value: (status.Element("id") != null ? status.Element("id").Value : "0")),
                             UserName =(status.Element("retweeted_status") != null ? status.Element("retweeted_status").Element("user").Element("name").Value :  (status.Element("user").Element("name") != null ? status.Element("user").Element("name").Value : null)),
                             ScreenName = (status.Element("retweeted_status") != null ? status.Element("retweeted_status").Element("user").Element("screen_name").Value : (status.Element("user").Element("screen_name") != null ? status.Element("user").Element("screen_name").Value : null)),
                             AccountName = accountName
                         };
            return result.ToList<TwitterMessage>();
        }

        /// <summary>
        /// Get all the twitts account wise.
        /// </summary>
        /// <returns></returns>
        public IEnumerable<TwitterMessage> GetAllTwitterMessages()
        {
            List<TwitterMessage> messages = new List<TwitterMessage>();
            IEnumerable<TwitterMessage> messagesPerAccount = null;
     
            messagesPerAccount = GetTwitterMessageByAccountType(TW_ACCOUNT1);
            messages.AddRange(messagesPerAccount.OrderByDescending(m=>m.CreatedDate));

            messagesPerAccount = GetTwitterMessageByAccountType(TW_ACCOUNT2);
            messages.AddRange(messagesPerAccount.OrderByDescending(m => m.CreatedDate));

            messagesPerAccount = GetTwitterMessageByAccountType(TW_ACCOUNT3);
            messages.AddRange(messagesPerAccount.OrderByDescending(m => m.CreatedDate));
            return messages;
         
        }
    }
}