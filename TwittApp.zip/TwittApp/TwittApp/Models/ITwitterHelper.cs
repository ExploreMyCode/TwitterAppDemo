﻿using System;
using System.Collections.Generic;
namespace TwittApp.Models
{
    interface ITwitterHelper
    {
        IEnumerable<TwitterMessage> GetAllTwitterMessages();
        IEnumerable<TwitterMessage> GetTwitterMessageByAccountType(string accountName);
        Twitts GetTwitts();
        List<TwittUser> GetUserDetailsPerAccount(System.Collections.Generic.List<TwitterMessage> messages, string accountName);
    }
}
