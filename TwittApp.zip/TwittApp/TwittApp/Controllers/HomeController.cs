﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;
using TwittApp.Models;
using Twitterizer;
//using Twitterizer.Framework;

namespace TwittApp.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
          TwitterHelper helper = new TwitterHelper();
          Twitts twitts = helper.GetTwitts();
          ViewBag.Message = "Twitter messages summary.";
          return View(twitts);
        }

        public JsonResult JsonResponse()
        {
            TwitterHelper helper = new TwitterHelper();
            Twitts twitts = helper.GetTwitts();
            ViewBag.Message = "Twitter messages summary.";
            return Json(twitts, JsonRequestBehavior.AllowGet);
        }

         public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";
            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}
