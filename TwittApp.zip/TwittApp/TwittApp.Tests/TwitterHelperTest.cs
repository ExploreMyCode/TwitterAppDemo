﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TwittApp.Models;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace TwittApp.Tests
{

    /// <summary>
    /// This class is used to test the business logic for twitter helper class which is responsible to fetch the twitts feeds
    /// </summary>
    [TestClass]
    public class TwitterHelperTest
    {
        private const string TW_ACCOUNT1 = "pay_by_phone";
        private const string TW_ACCOUNT2 = "PayByPhone";
        private const string TW_ACCOUNT3 = "PayByPhone_UK";
    
        [TestMethod]
        public void TestGet_TwitterMessageByAccountType()
        {
            //Arrange
            int expected_Count = 0;
            
            //Act
            TwitterHelper helper = new TwitterHelper();
            List<TwitterMessage> result = helper.GetTwitterMessageByAccountType(TW_ACCOUNT1) as List<TwitterMessage>;
            //Assert 

            Assert.IsNotNull(result);
            Assert.AreNotEqual(result.Count, expected_Count);

        }

        [TestMethod]
        public void Test_GetAllTwitterMessages()
        {
            int expectedCount = 0;
            TwitterHelper helper = new TwitterHelper();
            List<TwitterMessage> result = helper.GetAllTwitterMessages() as List<TwitterMessage>;
            int actual = result.Count;
            Assert.IsNotNull(result);
            Assert.AreNotEqual(result.Count, expectedCount);
         }

     
        [TestMethod]
        public void Test_GetUserDetailsPerAccount()
        {
            string expected = "PayByPhone";
            TwitterHelper helper = new TwitterHelper();
            List<TwitterMessage> messages = helper.GetAllTwitterMessages() as List<TwitterMessage>;
            List<TwittUser> users = helper.GetUserDetailsPerAccount(messages, TW_ACCOUNT1);
            var result = users.Where(x => x.UserName.Equals(expected, StringComparison.InvariantCultureIgnoreCase)).Select(x=>x.UserName).SingleOrDefault();
            Assert.IsNotNull(users);
            Assert.AreEqual(result,expected);
        }


        [TestMethod]
        public void Test_GetTwitts()
        {
            int expectedCount = 0;
            TwitterHelper helper = new TwitterHelper();
            Twitts result = helper.GetTwitts();
            Assert.IsNotNull(result);
            Assert.AreNotEqual(result.AllMessages.Count, expectedCount);
            Assert.AreNotEqual(result.TwittHeaderDetails.Count, expectedCount);
            Assert.IsNotNull(result);
        }
    }
}
