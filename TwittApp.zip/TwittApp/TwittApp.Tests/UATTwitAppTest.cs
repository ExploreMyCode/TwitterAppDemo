﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Linq;
using TwittApp.Models;
using System.Collections.Generic;


namespace TwittApp.Tests
{
    /// <summary>
    ///  This class is used to test the business logic for twitter helper class which is responsible to fetch the twitts feeds
    /// </summary>
    [TestClass]
    public class UATTwitAppTest
    {
        private const string TW_ACCOUNT1 = "pay_by_phone";
        private const string TW_ACCOUNT2 = "PayByPhone";
        private const string TW_ACCOUNT3 = "PayByPhone_UK";
      

        [TestMethod]
        public void Test_TwittMessagesByAccount()
        {
            int expectedCount = 0;
            TwittApp.Models.Twitts twitts = new Twitts();
            TwitterHelper helper = new TwitterHelper();
            twitts = helper.GetTwitts();
            
            List<TwitterMessage> result = twitts.AllMessages; 
            Assert.IsNotNull(result);

            //Verify that TW_ACCOUNT1 name exists in twitter messages 
            var actual = result.Where(a => a.ScreenName.Equals(TW_ACCOUNT1, StringComparison.InvariantCultureIgnoreCase));
            Assert.AreNotEqual(actual, expectedCount);

            //Verify that TW_ACCOUNT1 name exists in twitter messages 
            actual = result.Where(a => a.ScreenName.Equals(TW_ACCOUNT2, StringComparison.InvariantCultureIgnoreCase));
            Assert.AreNotEqual(actual.Count(), expectedCount);

            //Verify that TW_ACCOUNT2 name exists in twitter messages 
            actual = result.Where(a => a.ScreenName.Equals(TW_ACCOUNT2, StringComparison.InvariantCultureIgnoreCase));
            Assert.AreNotEqual(actual.Count(), expectedCount);

            //Verify that TW_ACCOUNT3 name exists in twitter messages 
            actual = result.Where(a => a.ScreenName.Equals(TW_ACCOUNT3, StringComparison.InvariantCultureIgnoreCase));
            Assert.AreNotEqual(actual.Count(), expectedCount);
            // verify twitt message by account type 

            var twittMsg = "Smart pilot program: helps find parking spots, pay by phone, and texts when the meter is running low. LOVE IT. http://t.co/b8UBszLO0A";

            actual = result.Where(a => a.AccountName.Equals(TW_ACCOUNT1, StringComparison.InvariantCultureIgnoreCase) && a.Text.ToLower().Contains(twittMsg.ToLower()));
            Assert.AreEqual(actual.Count(), 1);

        }

        [TestMethod]
        public void TestAggregation()
        {
            int expectedCount = 0;
            TwittApp.Models.Twitts twitts = new Twitts();
            TwitterHelper helper = new TwitterHelper();
            twitts = helper.GetTwitts();
            List<TwittHeader> result = twitts.TwittHeaderDetails;

            //Verify account name 
            Assert.IsNotNull(result);
            var actual = result.Select(x => x.AccountName.Equals(TW_ACCOUNT1));
            Assert.AreNotEqual(expectedCount, actual.Count());

            // Verify User name 
            var temp = result.SelectMany(x => x.TwittUsers).Where(x=>x.UserName.Equals("Serena Connelly", StringComparison.InvariantCultureIgnoreCase));
            Assert.AreEqual(temp.Count(), 1);
            //Verify number of twitts for user name "Serena Connelly"
            Assert.AreEqual(temp.Select(x => x.UserTwittsCount).SingleOrDefault(), 1);
        }
    }

    public class MyComparer : IEqualityComparer<string>
    {
        public bool Equals(string x, string y)
        {
            return x.ToLower().Contains(y.ToLower());
        }

        public int GetHashCode(string obj)
        {
            throw new NotImplementedException();
        }
    }


}
